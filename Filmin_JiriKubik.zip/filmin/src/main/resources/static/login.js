document.getElementById('loginForm').addEventListener('submit', async (event) => {
    event.preventDefault();

    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    if (!email || !password) {
        alert('Vyplňte prosím email i heslo');
        return;
    }

    const loginData = { email, password };

    const response = await fetch('/api/users/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
    });

    if (response.ok) {
        alert('Přihlášení úspěšné!');
        window.location.href = 'index.html';
    } else {
        const errorMessage = await response.text();
        alert('Chyba při přihlášení: ' + errorMessage);
    }



    try {
        const response = await fetch('/api/users/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(loginData),
        });

        if (response.ok) {
            alert('Přihlášení bylo úspěšné!');
            window.location.href = 'index.html';
        } else {
            const errorData = await response.json();
            alert('Chyba při přihlášení: ' + (errorData.message || 'Neznámá chyba'));
        }
    } catch (e) {
        alert('Přihlášení nebylo úspěšné');
    }
});
