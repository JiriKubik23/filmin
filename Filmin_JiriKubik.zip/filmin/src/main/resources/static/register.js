document.querySelectorAll('.plan button').forEach(button => {
    button.addEventListener('click', async (event) => {
        event.preventDefault();
        const email = document.getElementById('newEmail').value.trim();
        const password = document.getElementById('newPassword').value.trim();

        if (!email || !password) {
            alert('Vyplňte prosím email i heslo');
            return;
        }

        const planId = button.textContent.includes('ZDARMA') ? 1 : 2;

        const userData = { email, password, planId };

        try {
            const response = await fetch('/api/users', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });

            if (response.ok) {
                alert('Registrace proběhla úspěšně!');
                window.location.href = button.closest('a').href;
            } else {
                const errorData = await response.json();
                alert('Chyba při registraci: ' + (errorData.message || JSON.stringify(errorData)));
            }
        } catch (e) {
            alert('Chyba spojení :(');
        }
    });
});
