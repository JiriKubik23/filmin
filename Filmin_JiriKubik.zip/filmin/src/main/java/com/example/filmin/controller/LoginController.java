package com.example.filmin.controller;

import com.example.filmin.dto.LoginDTO;
import com.example.filmin.dto.UserEntity;
import com.example.filmin.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class LoginController {

    private final UserService userService;

    @Autowired
    public LoginController(UserService userService) {
        this.userService = userService;
    }


    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDTO loginDTO, HttpSession session) {
        UserEntity user = userService.findByEmail(loginDTO.getEmail());
        if (user == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Uživatel nenalezen");
        }

        boolean passwordMatches = userService.checkPassword(user, loginDTO.getPassword());
        if (!passwordMatches) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Heslo bylo zadáno špatně");
        }
        session.setAttribute("userId", user.getId());
        return ResponseEntity.ok("Přihlášení úspěšné");
    }



    @GetMapping("/session-check")
    public ResponseEntity<?> checkSession(HttpSession session) {
        Object userId = session.getAttribute("userId");
        if (userId != null) {
            return ResponseEntity.ok("Právě je příhlášený uživatel ID: " + userId);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Žádný uživatel není přihlášený.");
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpSession session) {
        session.invalidate();
        return ResponseEntity.ok("Odhlášení proběhlo úspěšně");
    }


    @DeleteMapping("/delete-account")
    public ResponseEntity<?> deleteAccount(HttpSession session) {
        Object userIdObj = session.getAttribute("userId");
        if (userIdObj == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Uživatel není přihlášen.");
        }

        Long userId = Long.valueOf(userIdObj.toString());
        userService.deleteById(userId);
        session.invalidate();

        return ResponseEntity.ok("Účet byl úspěšně smazán.");
    }


    @GetMapping("/user-info")
    public ResponseEntity<?> getUserInfo(HttpSession session) {
        Object userIdObj = session.getAttribute("userId");
        if (userIdObj == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Uživatel není přihlášen.");
        }

        Long userId = Long.parseLong(userIdObj.toString());
        Optional<UserEntity> optionalUser = userService.findUserById(userId);

        if (optionalUser.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Uživatel nenalezen.");
        }

        UserEntity user = optionalUser.get();
        String email = user.getEmail();
        String planName = user.getPlan().getNazev();

        Map<String, String> result = new HashMap<>();
        result.put("email", email);
        result.put("plan", planName);

        return ResponseEntity.ok(result);
    }


    @PostMapping("/change-plan")
    public ResponseEntity<?> changePlan(@RequestBody Map<String, Integer> body, HttpSession session) {
        Object userIdObj = session.getAttribute("userId");
        if (userIdObj == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Uživatel není přihlášen.");
        }

        Long userId = Long.parseLong(userIdObj.toString());
        Optional<UserEntity> optionalUser = userService.findUserById(userId);
        if (optionalUser.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Uživatel nenalezen.");
        }

        int planId = body.get("planId");
        userService.changeUserPlan(userId, planId);

        return ResponseEntity.ok("Plán byl úspěšně změněn.");
    }



}

