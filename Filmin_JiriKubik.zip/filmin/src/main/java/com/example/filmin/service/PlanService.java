package com.example.filmin.service;

import com.example.filmin.dto.PlanEntity;
import com.example.filmin.repository.PlanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PlanService {

    @Autowired
    private PlanRepository planRepository;

    public List<PlanEntity> findAllPlans() {
        return planRepository.findAll();
    }

    public Optional<PlanEntity> findPlanById(Long id) {
        return planRepository.findById(id);}




    public PlanEntity createPlan(PlanEntity plan) {
        return planRepository.save(plan);
    }

    public void deletePlan(Long id) {
        planRepository.deleteById(id);
    }

    public PlanEntity updatePlan(Long id, PlanEntity planData) {
        return planRepository.findById(id)
                .map(plan -> {
                    plan.setNazev(planData.getNazev());
                    plan.setCena(planData.getCena());
                    return planRepository.save(plan);
                })
                .orElseThrow(() -> new RuntimeException("Plan not found"));
    }

}
