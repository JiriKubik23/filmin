package com.example.filmin.controller;

import com.example.filmin.dto.PlanEntity;
import com.example.filmin.dto.UserDTO;
import com.example.filmin.dto.UserEntity;
import com.example.filmin.service.UserService;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;


@RestController
@RequestMapping("/api/users")

public class UserController {


    @Autowired
    private UserService userService;

@GetMapping("/{id}")
public ResponseEntity<UserDTO> getUserById(@PathVariable Long id) {
    return userService.findUserById(id)
            .map(userEntity -> new UserDTO(userEntity.getId(), userEntity.getEmail(), userEntity.getPassword(), userEntity.getPlan().getId()))
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
}


    @PutMapping("/{id}")
    public ResponseEntity<UserDTO> updateUser(@PathVariable Long id, @RequestBody UserDTO updatedUser) {
        return userService.updateUser(id, new UserEntity(updatedUser.getEmail(), updatedUser.getPassword(), null))
                .map(userEntity -> new UserDTO(userEntity.getId(), userEntity.getEmail(), userEntity.getPassword(), userEntity.getPlan().getId()))
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        try {
            userService.deleteUser(id);
            return ResponseEntity.noContent().build();
        } catch (EntityNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Autowired
    private com.example.filmin.repository.PlanRepository planRepository;

    @PostMapping
    public ResponseEntity<UserDTO> createUser(@Valid @RequestBody UserDTO dto) {
        PlanEntity plan = planRepository.findById(dto.getPlanId())
                .orElseThrow(() -> new RuntimeException("Plan nenalezen"));

        UserEntity user = new UserEntity(dto.getEmail(), dto.getPassword(), plan);
        UserEntity saved = userService.createUser(user);

        UserDTO result = new UserDTO(saved.getId(), saved.getPassword(), saved.getEmail(), saved.getPlan().getId());
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }





    @ControllerAdvice
    public class ValidationExceptionHandler {

        @ExceptionHandler(MethodArgumentNotValidException.class)
        public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
            Map<String, String> errors = new HashMap<>();
            ex.getBindingResult().getFieldErrors().forEach(error ->
                    errors.put(error.getField(), error.getDefaultMessage()));
            return new ResponseEntity<>(errors, HttpStatus.BAD_REQUEST);
        }

    }
}
