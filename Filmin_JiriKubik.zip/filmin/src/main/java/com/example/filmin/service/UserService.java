package com.example.filmin.service;

import com.example.filmin.dto.PlanEntity;
import com.example.filmin.dto.UserEntity;
import com.example.filmin.dto.UserRegistrationDTO;
import com.example.filmin.repository.PlanRepository;
import com.example.filmin.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<UserEntity> findAllUsers() {
        return userRepository.findAll();
    }

    public Optional<UserEntity> findUserById(Long id) {
        return userRepository.findById(id);
    }



    public UserEntity findByEmail(String email) {
        return userRepository.findByEmail(email);
    }


    public boolean checkPassword(UserEntity user, String rawPassword) {
        return rawPassword.equals(user.getPassword());
    }





    public UserEntity createUser(UserEntity user) {
        return userRepository.save(user);
    }

    public void deleteUser(Long id) {
        UserEntity user = userRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Uživatel nenalezen"));
        userRepository.delete(user);
    }


    public void deleteById(Long id) {
        userRepository.deleteById(id);
    }


    public Optional<UserEntity> updateUser(Long id, UserEntity userData) {
        return userRepository.findById(id)
                .map(user -> {
                    user.setEmail(userData.getEmail());
                    user.setPassword(userData.getPassword());
                    return userRepository.save(user);
                });
    }


    @Transactional
    public void changeUserPlan(Long userId, int planId) {
        Optional<UserEntity> userOpt = userRepository.findById(userId);
        Optional<PlanEntity> planOpt = planRepository.findById((long) planId);
        if (userOpt.isPresent() && planOpt.isPresent()) {
            UserEntity user = userOpt.get();
            user.setPlan(planOpt.get());
            userRepository.save(user);
        }
    }





    @Autowired
    private PlanRepository planRepository;

    public UserEntity registerUser(UserRegistrationDTO dto) {
        PlanEntity plan = planRepository.findById(dto.getPlanId())
                .orElseThrow(() -> new RuntimeException("Plán nenalezen"));
        UserEntity user = new UserEntity(dto.getEmail(), dto.getPassword(), plan);
        return userRepository.save(user);
    }


}
