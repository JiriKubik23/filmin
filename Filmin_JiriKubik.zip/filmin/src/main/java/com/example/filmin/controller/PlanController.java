package com.example.filmin.controller;

import com.example.filmin.dto.PlanDTO;
import com.example.filmin.service.PlanService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/api/plans")
public class PlanController {

    @Autowired
    private PlanService planService;


    @GetMapping
    public List<PlanDTO> getAllPlans() {
        return planService.findAllPlans()
                .stream()
                .map(plan -> new PlanDTO(plan.getId(), plan.getNazev(), plan.getCena()))
                .toList();
    }


    @GetMapping("/{id}")
    public ResponseEntity<PlanDTO> getPlanById(@PathVariable Long id) {
        return planService.findPlanById(id)
                .map(plan -> new PlanDTO(plan.getId(), plan.getNazev(), plan.getCena()))
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}

/*
@RestController
@RequestMapping("/api/plans")

public class PlanController {
    private final List<PlanDTO> plans = new ArrayList<>();
    private final AtomicLong idCounter = new AtomicLong();

    @Autowired
    private PlanService planService;

    @GetMapping("/{id}")
    public ResponseEntity<PlanDTO> getPlanById(@PathVariable Long id) {
        return plans.stream()
                .filter(plan -> plan.getId().equals(id))
                .findFirst()
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<PlanDTO> createPlan(@Valid @RequestBody PlanDTO plan) {
        plan.setId(idCounter.incrementAndGet());
        plans.add(plan);
        return new ResponseEntity<>(plan, HttpStatus.CREATED);
    }


    @PutMapping
    public ResponseEntity<PlanDTO> updatePlan(@PathVariable Long id, @RequestBody PlanDTO updatedPlan) {
        for (PlanDTO plan : plans) {
            if (plan.getId().equals(id)) {
                plan.setNazev(updatedPlan.getNazev());
                plan.setCena(updatedPlan.getCena());
                return ResponseEntity.ok(plan);
            }
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePlan(@PathVariable Long id) {
        boolean removed = plans.removeIf(plan -> plan.getId().equals(id));
        if (removed) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }



}
 */