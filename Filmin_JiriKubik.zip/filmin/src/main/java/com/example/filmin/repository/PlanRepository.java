package com.example.filmin.repository;


import com.example.filmin.dto.PlanEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PlanRepository extends JpaRepository<PlanEntity, Long>{
    Optional<PlanEntity> findByNazev(String nazev);


}
