package com.example.filmin.dto;

import jakarta.persistence.*;

@Entity
@Table(name = "plans")
public class PlanEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String nazev;

    @Column(nullable = false)
    private int cena;


    public PlanEntity(Long id, String nazev, int cena) {
        this.id = id;
        this.nazev = nazev;
        this.cena = cena;
    }

    public PlanEntity() {

    }



    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getNazev() {
        return nazev;
    }
    public void setNazev(String nazev) {
        this.nazev = nazev;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }
}
