package com.example.filmin.dto;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class UserEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;




    @ManyToOne
    @JoinColumn(name = "plan_id")
    private PlanEntity plan;


    public UserEntity() {

    }



    public UserEntity(String email, String password, PlanEntity plan) {
        this.email = email;
        this.password = password;
        this.plan = plan;
    }

    public PlanEntity getPlan() {
        return plan;
    }


    public void setPlan(PlanEntity plan) {
        this.plan = plan;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


}
