package com.example.filmin.dto;


import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public class UserDTO {
    private Long id;

    @NotBlank(message = "Heslo nesmí být prázdné")
    private String password;

    @Email(message = "Email není ve správném formátu")
    @NotBlank(message = "Email nesmí být prázdný")
    private String email;

    private Long planId;  //

    public Long getPlanId() {
        return planId;
    }

    public void setPlanId(Long planId) {
        this.planId = planId;
    }


    public UserDTO() {

    }

    public UserDTO(Long id, String password, String email, Long planId) {
        this.id = id;
        this.password = password;
        this.email = email;
        this.planId = planId;
    }

public Long getId() {
        return id;
}


public void setId(Long id) {
    this.id = id;
}

public String getPassword() {
    return password;
}

public void setPassword(String password) {
    this.password = password;
}

public String getEmail() {
    return email;
}

public void setEmail(String email) {
    this.email = email;
}


}

