package com.example.filmin.dto;



import jakarta.validation.constraints.NotBlank;


public class PlanDTO {
    private Long id;

    @NotBlank
    private String nazev;
    private int cena;


    public PlanDTO() {

    }

    public PlanDTO(Long id, String nazev, int cena) {
        this.id = id;
        this.nazev = nazev;
        this.cena = cena;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getNazev() {
        return nazev;
    }

    public void setNazev(String nazev) {
        this.nazev = nazev;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }
}
