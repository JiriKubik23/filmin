package com.example.filmin;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.filmin.dto.PlanEntity;
import com.example.filmin.dto.UserEntity;
import com.example.filmin.repository.PlanRepository;
import com.example.filmin.repository.UserRepository;


@SpringBootApplication
public class FilminApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilminApplication.class, args);
	}



}
