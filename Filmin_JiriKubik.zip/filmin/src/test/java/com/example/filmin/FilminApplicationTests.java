package com.example.filmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilminApplicationTests {

	@Test
	void contextLoads() {
	}

}
